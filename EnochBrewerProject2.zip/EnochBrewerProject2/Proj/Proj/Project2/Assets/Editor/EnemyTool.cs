﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class EnemyTool:EditorWindow {
	public List<Enemies> enemyList = new List<Enemies>();

	//enemy stats
	string nameString;
	int health, atk,def,agi;
	float atkTime;
	bool isMagic = false;
	int manaPool = 0;

	bool healthFlag = true;
	bool manaPoolFlag = true;
	bool isMagicFlag = true;
	bool atkTimeFlag = true;
	bool agiFlag = true;
	bool defFlag = true;
	bool atkFlag = true;
	bool nameFlag = true;
	bool enemySpriteFlag = true;
	List<string> enemyNameList = new List<string>();
	string[] enemyNames;
	int currentChoice = 0;
	int lastChoice = 0;
	Sprite enemySprite;

	[MenuItem("Custom Tools/Enemy Tool %g")]
	private static void blahblah(){
		EditorWindow.GetWindow<EnemyTool> ();
	}

	void Awake(){
		getEnemies();
	}

	void OnGUI(){
		currentChoice = EditorGUILayout.Popup ("Options: ",currentChoice, enemyNameList.ToArray());

		nameString = EditorGUILayout.TextField ("Name: ", nameString);

		if (nameString == "" || nameString == null) {
			EditorGUILayout.HelpBox ("Name can not be blank", MessageType.Error);
			nameFlag = true;
		} else {
			nameFlag = false;
		}

		health = EditorGUILayout.IntField ("Health: ", health);

		if (health < 1 || health > 300) {
			EditorGUILayout.HelpBox ("Health can no be less than 1 or greater than 300", MessageType.Error);
			healthFlag = true;
		} else {
			healthFlag = false;
		}

		atk = EditorGUILayout.IntField ("Atk: ", atk);

		if (atk < 1 || atk > 100) {
			EditorGUILayout.HelpBox ("Attack can not be less than 1 or greater than 100", MessageType.Error);
			atkFlag = true;
		} else {
			atkFlag = false;
		}

		def = EditorGUILayout.IntField ("Def: ", def);

		if (def < 1 || def > 100) {
			EditorGUILayout.HelpBox ("Defense can not be less than 1 or greater than 100", MessageType.Error);
			defFlag = true;
		} else {
			defFlag = false;
		}

		agi = EditorGUILayout.IntField ("Agi: ", agi);

		if (agi < 1 || agi > 100) {
			EditorGUILayout.HelpBox ("Agility can not be less than 1 or greater than 100", MessageType.Error);
			agiFlag = true;
		} else {
			agiFlag = false;
		}

		atkTime = EditorGUILayout.FloatField ("Atk Time: ", atkTime);

		if (atkTime < 1 || atkTime > 20) {
			EditorGUILayout.HelpBox ("Attack Time must be between 1 and 20", MessageType.Error);
			atkTimeFlag = true;
		} else {
			atkTimeFlag = false;
		}

		isMagic = EditorGUILayout.BeginToggleGroup("Is Magic?", isMagic);
		manaPool = EditorGUILayout.IntField ("Mana Pool: ", manaPool);
		if (manaPool < 0 || manaPool > 100) {
			EditorGUILayout.HelpBox ("Mana Pool can not be less than 0 or greater than 100", MessageType.Error);
			manaPoolFlag = true;
		} else {
			manaPoolFlag = false;
		}
		EditorGUILayout.EndToggleGroup();


		enemySprite = (Sprite) EditorGUILayout.ObjectField("Image", enemySprite, typeof (Sprite), false);
		if (enemySprite == null) {
			EditorGUILayout.HelpBox ("Image can not be blank", MessageType.Error);
			enemySpriteFlag = true;
		} else {
			enemySpriteFlag = false;
		}
		if (currentChoice != 0) {
			EditorGUILayout.LabelField ("Information About Selected Enemy");
			EditorGUILayout.HelpBox (
				"Enemy Name: " + enemyList [currentChoice - 1].emname + "\n" +
				"Enemy Health: " + enemyList [currentChoice - 1].health + "\n" +
				"Enemy Atk: " + enemyList [currentChoice - 1].atk + "\n" +
				"Enemy Def: " + enemyList [currentChoice - 1].def + "\n" +
				"Enemy Agi: " + enemyList [currentChoice - 1].agi + "\n" +
				"Enemy Atk Time: " + enemyList [currentChoice - 1].atkTime + "\n" +
				"Enemy isMagic: " + enemyList [currentChoice - 1].isMagic + "\n" +
				"Enemy Mana Pool: " + enemyList [currentChoice - 1].manaPool + "\n" +
				"Enemy Sprite Name: " + enemyList [currentChoice - 1].mySprite.texture, 
				MessageType.Info);
		}

		if (currentChoice != lastChoice) {
			if (currentChoice != 0) {
				
				getValues (currentChoice);
			}
			if (currentChoice == 0) {
				resetValues ();
			}
			lastChoice = currentChoice;
		}

		if ((!isMagic && !nameFlag && !healthFlag && !atkFlag && !defFlag && !agiFlag && !atkTimeFlag && !enemySpriteFlag && !manaPoolFlag) || (isMagic && !nameFlag && !healthFlag && !atkFlag && !defFlag && !agiFlag && !atkTimeFlag && !enemySpriteFlag && !manaPoolFlag)) {
			if (currentChoice == 0) {
				//Debug.Log ("New Enemy Creation");
				if (GUILayout.Button ("create")) {
					createEnemy (nameString);
				}

			} else if (currentChoice != 0) {
				
				if (GUILayout.Button ("Save")) {
					alterEnemy (enemyList [currentChoice - 1], nameString, health, atk, def, agi, atkTime, isMagic, manaPool, enemySprite);
				}

			}

		}

	}
	private void resetValues() {
		nameString = "";
		health = 0;
		atk = 0;
		def = 0;
		agi = 0;
		atkTime = 0f;
		isMagic = false;
		manaPool = 0;
		enemySprite = null;
	}

	private void getValues(int pCurrentChoice) {
		nameString = enemyList [pCurrentChoice - 1].emname;
		health = enemyList [pCurrentChoice - 1].health;
		atk = enemyList [pCurrentChoice - 1].atk;
		def = enemyList [pCurrentChoice - 1].def;
		agi = enemyList [pCurrentChoice - 1].agi;
		atkTime = enemyList [pCurrentChoice - 1].atkTime;
		isMagic = enemyList [pCurrentChoice - 1].isMagic;
		manaPool = enemyList [pCurrentChoice - 1].manaPool;
		enemySprite = enemyList [pCurrentChoice - 1].mySprite;
	}

	private void getEnemies(){
		enemyList.Clear ();
		enemyNameList.Clear ();
		string[] guids = AssetDatabase.FindAssets ("t:Enemies");
		foreach (string guid in guids) {
			string myString = AssetDatabase.GUIDToAssetPath (guid);

			Enemies enemyInst = AssetDatabase.LoadAssetAtPath (myString, typeof(Enemies)) as Enemies;

			enemyList.Add (enemyInst);
		}
			
		foreach (Enemies e in enemyList) {
			enemyNameList.Add (e.emname);
		}

		enemyNameList.Insert (0, "New");
		//enemyNames = enemyNameList.ToArray ();
		//OnGUI ();

	}

	private void createEnemy(string pName){
		Enemies myEnemy = ScriptableObject.CreateInstance<Enemies> ();
		AssetDatabase.CreateAsset (myEnemy, "Assets/Resources/Data/EnemyData/" + pName.Replace (" ", "_") + ".asset");
		alterEnemy (myEnemy, pName, health, atk, def, agi, atkTime, isMagic, manaPool, enemySprite);
	}
		

	private void alterEnemy(Enemies currentEnemy, string pName, int pHealth, int pAtk, int pDef, int pAgi, float pAtkTime, bool pIsMagic, int pManaPool, Sprite pSprite ) {
		currentEnemy.emname = pName;
		currentEnemy.health = pHealth;
		currentEnemy.atk = pAtk;
		currentEnemy.def = pDef;
		currentEnemy.agi = pAgi;
		currentEnemy.atkTime = pAtkTime;
		currentEnemy.isMagic = pIsMagic;
		currentEnemy.manaPool = pManaPool;
		currentEnemy.mySprite = pSprite;
		AssetDatabase.SaveAssets ();
		getEnemies ();
		resetValues ();

	}



}
